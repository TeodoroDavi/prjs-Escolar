const moduloA = require('./moduloA');
const calculadora = require('./calculadora');

console.log(moduloA.bemvindo);

console.log(moduloA.dividir(7,3));
console.log(calculadora.somar(5,2));

