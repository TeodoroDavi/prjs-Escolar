const alunos = [
    {"rm": 1, "nome":"teodoro", "media": 10 , "situação": "cursando"},
    {"rm": 2, "nome":"rhaziel", "media": 10 , "situação": "cursando"},
    {"rm": 3, "nome":"laura", "media": 10 , "situação": "trancado"},
    {"rm": 4, "nome":"giovanna", "media": 10 , "situação": "cursando"},
];

export default () => alunos;